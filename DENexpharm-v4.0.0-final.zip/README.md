# DENexpharm v4.0.0 — deployment-ready foundation

DENexpharm is a pharmacy learning and competition platform for Nigerian and international pharmacy students.

## Included

- Express 5 backend and Express-5-safe SPA fallback
- Node.js 18+ support
- PostgreSQL support for persistent production storage (Render Postgres, Supabase, Neon, etc.)
- JSON fallback for local/demo use
- Secure password hashing with bcryptjs
- JWT authentication in an httpOnly cookie plus optional Bearer token
- Profile fields: country, university, level and academic year
- Scalable question model: subject, course code, country, academic year, level, difficulty, mode and explanation
- Question filters and random practice sets
- Server-recorded quiz scores, XP and leaderboard
- Admin question creation/editing/deactivation endpoints
- Paystack server-side initialization, callback verification and signed webhook verification
- Premium fulfillment checks status, amount, currency and prevents duplicate fulfillment
- Rate limiting, Helmet and CORS
- Student tools: GPA calculator, pharmacopoeia concepts and multilingual pharmacy phrases
- Limited internal ad slot for free accounts; premium hides it
- No Paystack secret is placed in frontend code

## Local run

1. Install Node.js 18+.
2. Copy `.env.example` to `.env` and set a strong `JWT_SECRET`.
3. Run `npm install`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

Without `DATABASE_URL`, the app uses `data/db.json` for local testing. For a real deployment, configure PostgreSQL so user/question/payment data is persistent.

## Render / similar Node hosting

- Build command: `npm install`
- Start command: `npm start`
- Node version: 18 or newer
- Set `DATABASE_URL` to your PostgreSQL connection string.
- Set `JWT_SECRET` to a long random value.
- Set `FRONTEND_ORIGIN` to your deployed app URL.
- Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before first production boot.
- Add Paystack variables when payments are ready.

Do not use `start` as a shell command. The platform should run `npm start`, which executes `node server.js`.

## PostgreSQL

The server automatically creates the tables in `schema.sql` when `DATABASE_URL` is present and seeds the initial question bank if the `questions` table is empty.

The database is the production source of truth. The JSON file is only a fallback for local/demo use.

## Paystack setup

Set:

- `PAYSTACK_SECRET_KEY`
- `PAYSTACK_CURRENCY=NGN`
- `PREMIUM_PRICE_NGN=5000` (change the price before launch if desired)
- `PAYSTACK_CALLBACK_URL=https://YOUR-DOMAIN/api/payments/paystack/callback`

Configure the Paystack webhook URL as:

`https://YOUR-DOMAIN/api/payments/paystack/webhook`

The backend verifies the webhook's `x-paystack-signature` using HMAC-SHA512. It also verifies the transaction with Paystack before granting Premium and checks the expected amount/currency.

## Admin question API

Use an authenticated admin account.

`POST /api/admin/questions`

Example body:

```json
{
  "subject":"Pharmacology",
  "course_code":"PHA",
  "country":"Nigeria",
  "academic_year":"2026",
  "level":"200",
  "difficulty":"medium",
  "mode":"practice",
  "question":"Your question here",
  "options":["A","B","C","D"],
  "answer_index":0,
  "explanation":"Short explanation",
  "source_note":"Internal curriculum reference"
}
```

The structure is designed so the bank can grow to thousands or more questions without changing the application architecture.

## Important production settings

- Replace the example admin password.
- Use a strong random JWT secret.
- Use Paystack test keys first, then switch to live keys only after testing.
- Keep `PAYSTACK_SECRET_KEY` server-side.
- Use HTTPS on the deployed domain.
- Use PostgreSQL rather than the JSON fallback for production persistence.
- Do not place copyrighted pharmacopoeia monographs into the question bank without appropriate rights.
