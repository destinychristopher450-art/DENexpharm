'use strict';

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const APP_VERSION = '4.0.0';
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const QUESTION_FILE = path.join(DATA_DIR, 'questions.json');
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-change-this-secret';
const NODE_ENV = process.env.NODE_ENV || 'development';
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || '';
const SUPPORTED_YEARS = (process.env.SUPPORTED_YEARS || '2024,2025,2026').split(',').map(x => x.trim()).filter(Boolean);
const CURRENT_YEAR = process.env.CURRENT_YEAR || '2026';
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || '';
const PAYSTACK_CURRENCY = (process.env.PAYSTACK_CURRENCY || 'NGN').toUpperCase();
const PREMIUM_PRICE_NGN = Number(process.env.PREMIUM_PRICE_NGN || 5000);
const PREMIUM_AMOUNT_SUBUNIT = Math.round(PREMIUM_PRICE_NGN * 100);
const PREMIUM_NAME = process.env.PREMIUM_NAME || 'DENexpharm Premium';
const PAYSTACK_CALLBACK_URL = process.env.PAYSTACK_CALLBACK_URL || '';

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, JSON.stringify({ users: [], questions: [], scores: [], payments: [], audit_logs: [] }, null, 2));

let db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
for (const key of ['users', 'questions', 'scores', 'payments', 'audit_logs']) if (!Array.isArray(db[key])) db[key] = [];

function saveDb() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

let pool = null;
if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: /sslmode=require|neon|supabase/i.test(process.env.DATABASE_URL) ? { rejectUnauthorized: false } : undefined,
    max: 5,
    idleTimeoutMillis: 30000
  });
}

async function pgQuery(text, params = []) {
  if (!pool) throw new Error('PostgreSQL is not configured');
  return (await pool.query(text, params)).rows;
}

async function initPostgres() {
  if (!pool) return;
  const schema = fs.readFileSync(path.join(ROOT, 'schema.sql'), 'utf8');
  await pool.query(schema);
  await seedQuestionsPostgres();
  await ensureAdminPostgres();
}

function loadSeedQuestions() {
  if (!fs.existsSync(QUESTION_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(QUESTION_FILE, 'utf8')); } catch { return []; }
}

async function seedQuestionsPostgres() {
  const count = await pgQuery('SELECT COUNT(*)::int AS count FROM questions');
  if (count[0].count > 0) return;
  const questions = loadSeedQuestions();
  for (const q of questions) {
    await pgQuery(`INSERT INTO questions
      (subject,course_code,country,academic_year,level,difficulty,mode,question,options,answer_index,explanation)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [q.subject, q.course_code || '', q.country || 'Global', q.academic_year || CURRENT_YEAR, q.level || 'All', q.difficulty || 'medium', q.mode || 'practice', q.question, JSON.stringify(q.options), q.answer_index, q.explanation || '']);
  }
}

async function ensureAdminPostgres() {
  const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD || '';
  if (!email || !password || password.length < 8) return;
  const rows = await pgQuery('SELECT id FROM users WHERE email=$1', [email]);
  const hash = await bcrypt.hash(password, 12);
  if (!rows.length) {
    await pgQuery(`INSERT INTO users(email,password_hash,name,admin,country,academic_year)
      VALUES($1,$2,$3,TRUE,$4,$5)`, [email, hash, 'DENexpharm Admin', 'Nigeria', CURRENT_YEAR]);
  } else {
    await pgQuery('UPDATE users SET admin=TRUE, password_hash=$1, updated_at=NOW() WHERE email=$2', [hash, email]);
  }
}

function seedJsonQuestions() {
  if (db.questions.length) return;
  db.questions = loadSeedQuestions().map((q, i) => ({ id: i + 1, ...q, active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }));
  saveDb();
}
seedJsonQuestions();

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: FRONTEND_ORIGIN || true, credentials: true }));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: true, legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many authentication attempts. Try again later.' } });
app.use('/api', apiLimiter);

app.use(express.json({
  limit: '1mb',
  verify: (req, _res, buf) => { req.rawBody = Buffer.from(buf); }
}));

function cookieOptions() {
  return {
    httpOnly: true,
    secure: NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 30 * 24 * 60 * 60 * 1000,
    path: '/'
  };
}

function makeToken(user) {
  return jwt.sign({ id: String(user.id), email: user.email, admin: !!user.admin }, JWT_SECRET, { expiresIn: '30d' });
}

function safeUser(u) {
  return {
    id: String(u.id), email: u.email, name: u.name, university: u.university || '',
    country: u.country || 'Nigeria', level: u.level || '200', academic_year: u.academic_year || CURRENT_YEAR,
    xp: Number(u.xp || 0), quiz_points: Number(u.quiz_points || 0), premium: !!u.premium,
    premium_until: u.premium_until || null, admin: !!u.admin
  };
}

async function getUserById(id) {
  if (pool) return (await pgQuery('SELECT * FROM users WHERE id=$1', [id]))[0] || null;
  return db.users.find(u => String(u.id) === String(id)) || null;
}

async function getUserByEmail(email) {
  if (pool) return (await pgQuery('SELECT * FROM users WHERE email=$1', [email]))[0] || null;
  return db.users.find(u => u.email === email) || null;
}

function parseCookies(req) {
  const raw = req.headers.cookie || '';
  return Object.fromEntries(raw.split(';').map(x => x.trim()).filter(Boolean).map(x => { const i=x.indexOf('='); return i<0 ? [x,''] : [decodeURIComponent(x.slice(0,i)), decodeURIComponent(x.slice(i+1))]; }));
}

function authPayload(req) {
  const header = req.get('authorization') || '';
  const cookies = parseCookies(req);
  let token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token && cookies.denex_session) token = cookies.denex_session;
  if (!token) return null;
  try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}

async function requireAuth(req, res, next) {
  const payload = authPayload(req);
  if (!payload) return res.status(401).json({ error: 'Sign in required' });
  const user = await getUserById(payload.id);
  if (!user) return res.status(401).json({ error: 'Account not found' });
  req.user = user;
  req.auth = payload;
  next();
}

async function requireAdmin(req, res, next) {
  await requireAuth(req, res, async () => {
    if (!req.user.admin) return res.status(403).json({ error: 'Admin access required' });
    next();
  });
}

async function audit(userId, action, details = {}) {
  if (pool) {
    await pgQuery('INSERT INTO audit_logs(user_id,action,details) VALUES($1,$2,$3)', [userId || null, action, JSON.stringify(details)]);
  } else {
    db.audit_logs.push({ id: Date.now() + Math.random(), user_id: userId || null, action, details, created_at: new Date().toISOString() });
    saveDb();
  }
}

function randomReference() {
  return `DEN_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`;
}

function amountMatches(amount) {
  return Number(amount) === PREMIUM_AMOUNT_SUBUNIT;
}

async function recordPaymentPending({ userId, reference, amount, currency, metadata }) {
  if (pool) {
    const rows = await pgQuery(`INSERT INTO payments(user_id,provider,reference,amount,currency,status,metadata)
      VALUES($1,'paystack',$2,$3,$4,'pending',$5) RETURNING *`, [userId, reference, amount, currency, JSON.stringify(metadata || {})]);
    return rows[0];
  }
  const p = { id: Date.now() + Math.random(), user_id: userId, provider: 'paystack', reference, amount, currency, status: 'pending', metadata: metadata || {}, provider_response: {}, fulfilled: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
  db.payments.push(p); saveDb(); return p;
}

async function getPayment(reference) {
  if (pool) return (await pgQuery('SELECT * FROM payments WHERE reference=$1', [reference]))[0] || null;
  return db.payments.find(p => p.reference === reference) || null;
}

async function fulfillPremium(reference, providerResponse) {
  const payment = await getPayment(reference);
  if (!payment) return { ok: false, reason: 'payment_not_found' };
  if (payment.fulfilled) return { ok: true, already: true };
  const data = providerResponse?.data || providerResponse || {};
  if (data.status !== 'success' || !amountMatches(data.amount) || String(data.currency || PAYSTACK_CURRENCY).toUpperCase() !== PAYSTACK_CURRENCY) {
    if (pool) await pgQuery('UPDATE payments SET status=$1, provider_response=$2, updated_at=NOW() WHERE reference=$3', [data.status || 'failed', JSON.stringify(providerResponse || {}), reference]);
    else { payment.status = data.status || 'failed'; payment.provider_response = providerResponse || {}; payment.updated_at = new Date().toISOString(); saveDb(); }
    return { ok: false, reason: 'verification_mismatch' };
  }
  const until = new Date(); until.setFullYear(until.getFullYear() + 1);
  if (pool) {
    await pgQuery('UPDATE payments SET status=\'success\', provider_response=$1, fulfilled=TRUE, updated_at=NOW() WHERE reference=$2', [JSON.stringify(providerResponse || {}), reference]);
    await pgQuery('UPDATE users SET premium=TRUE, premium_until=$1, updated_at=NOW() WHERE id=$2', [until, payment.user_id]);
  } else {
    payment.status = 'success'; payment.provider_response = providerResponse || {}; payment.fulfilled = true; payment.updated_at = new Date().toISOString();
    const user = db.users.find(u => String(u.id) === String(payment.user_id));
    if (user) { user.premium = true; user.premium_until = until.toISOString(); user.updated_at = new Date().toISOString(); }
    saveDb();
  }
  await audit(payment.user_id, 'premium_activated', { reference });
  return { ok: true, already: false };
}

async function paystackRequest(url, options = {}) {
  if (!PAYSTACK_SECRET_KEY) throw new Error('PAYSTACK_SECRET_KEY is not configured');
  const response = await fetch(`https://api.paystack.co${url}`, {
    ...options,
    headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.status === false) {
    const e = new Error(data.message || `Paystack request failed (${response.status})`);
    e.status = response.status; e.paystack = data; throw e;
  }
  return data;
}

// Health
app.get('/api/health', async (_req, res) => {
  let dbMode = pool ? 'postgresql' : 'json';
  let databaseOk = true;
  if (pool) { try { await pgQuery('SELECT 1'); } catch { databaseOk = false; } }
  res.json({ ok: databaseOk, version: APP_VERSION, database: dbMode, databaseOk, currentYear: CURRENT_YEAR, supportedYears: SUPPORTED_YEARS });
});

// Public configuration
app.get('/api/config', (_req, res) => res.json({
  app: 'DENexpharm', version: APP_VERSION, currentYear: CURRENT_YEAR, supportedYears: SUPPORTED_YEARS,
  premium: { enabled: !!PAYSTACK_SECRET_KEY, price: PREMIUM_PRICE_NGN, currency: PAYSTACK_CURRENCY, name: PREMIUM_NAME },
  ads: { provider: process.env.ADS_PROVIDER || 'internal', clientId: process.env.ADSENSE_CLIENT_ID || '', slotId: process.env.ADSENSE_SLOT_ID || '' }
}));

// Auth
app.post('/api/auth/register', authLimiter, async (req, res) => {
  const b = req.body || {};
  const email = String(b.email || '').trim().toLowerCase();
  const password = String(b.password || '');
  const name = String(b.name || '').trim();
  if (!name || !email || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8) return res.status(400).json({ error: 'Enter a valid name, email and password of at least 8 characters.' });
  if (await getUserByEmail(email)) return res.status(409).json({ error: 'Email already registered.' });
  const hash = await bcrypt.hash(password, 12);
  let user;
  if (pool) {
    user = (await pgQuery(`INSERT INTO users(email,password_hash,name,university,country,level,academic_year)
      VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [email, hash, name, String(b.university || ''), String(b.country || 'Nigeria'), String(b.level || '200'), String(b.academic_year || CURRENT_YEAR)]))[0];
  } else {
    user = { id: Date.now(), email, password_hash: hash, name, university: String(b.university || ''), country: String(b.country || 'Nigeria'), level: String(b.level || '200'), academic_year: String(b.academic_year || CURRENT_YEAR), xp: 0, quiz_points: 0, premium: false, premium_until: null, admin: false, created_at: new Date().toISOString(), updated_at: new Date().toISOString() };
    db.users.push(user); saveDb();
  }
  const token = makeToken(user);
  res.cookie('denex_session', token, cookieOptions());
  await audit(user.id, 'register');
  res.status(201).json({ user: safeUser(user), token });
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  const user = await getUserByEmail(email);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: 'Invalid email or password.' });
  const token = makeToken(user);
  res.cookie('denex_session', token, cookieOptions());
  await audit(user.id, 'login');
  res.json({ user: safeUser(user), token });
});

app.post('/api/auth/logout', (req, res) => { res.clearCookie('denex_session', { path: '/' }); res.json({ ok: true }); });

app.get('/api/me', requireAuth, async (req, res) => res.json({ user: safeUser(req.user) }));

app.put('/api/me', requireAuth, async (req, res) => {
  const b = req.body || {};
  const fields = {
    name: String(b.name ?? req.user.name).trim(), university: String((b.university ?? req.user.university) || ''),
    country: String((b.country ?? req.user.country) || 'Nigeria'), level: String((b.level ?? req.user.level) || '200'),
    academic_year: String((b.academic_year ?? req.user.academic_year) || CURRENT_YEAR)
  };
  if (!fields.name) return res.status(400).json({ error: 'Name is required.' });
  let user;
  if (pool) user = (await pgQuery(`UPDATE users SET name=$1,university=$2,country=$3,level=$4,academic_year=$5,updated_at=NOW() WHERE id=$6 RETURNING *`, Object.values(fields).concat(req.user.id)))[0];
  else { Object.assign(req.user, fields, { updated_at: new Date().toISOString() }); saveDb(); user = req.user; }
  res.json({ user: safeUser(user) });
});

// Question bank
app.get('/api/questions', async (req, res) => {
  const subject = String(req.query.subject || '').trim();
  const country = String(req.query.country || 'Global').trim();
  const year = String(req.query.year || CURRENT_YEAR).trim();
  const level = String(req.query.level || 'All').trim();
  const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 100);
  if (pool) {
    const params = [year, level];
    let where = `active=true AND (academic_year=$1 OR academic_year='All') AND (level=$2 OR level='All')`;
    if (subject) { params.push(subject); where += ` AND subject=$${params.length}`; }
    if (country && country !== 'Global') { params.push(country); where += ` AND (country=$${params.length} OR country='Global')`; }
    params.push(limit);
    const rows = await pgQuery(`SELECT id,subject,course_code,country,academic_year,level,difficulty,mode,question,options,answer_index,explanation,source_note FROM questions WHERE ${where} ORDER BY RANDOM() LIMIT $${params.length}`, params);
    return res.json({ questions: rows });
  }
  let rows = db.questions.filter(q => q.active && (q.academic_year === year || q.academic_year === 'All') && (q.level === level || q.level === 'All'));
  if (subject) rows = rows.filter(q => q.subject === subject);
  if (country && country !== 'Global') rows = rows.filter(q => q.country === country || q.country === 'Global');
  rows = rows.sort(() => Math.random() - 0.5).slice(0, limit);
  res.json({ questions: rows });
});

app.get('/api/subjects', async (_req, res) => {
  const subjects = pool ? (await pgQuery('SELECT DISTINCT subject FROM questions WHERE active=true ORDER BY subject')).map(x => x.subject) : [...new Set(db.questions.filter(q => q.active).map(q => q.subject))].sort();
  res.json({ subjects });
});

app.post('/api/scores', requireAuth, async (req, res) => {
  const b = req.body || {};
  const score = Math.max(0, Number(b.score || 0));
  const total = Math.max(0, Number(b.total || 0));
  if (!b.subject || !total || score > total) return res.status(400).json({ error: 'Invalid score submission.' });
  const xp = score * 10;
  if (pool) {
    await pgQuery('INSERT INTO scores(user_id,subject,score,total,mode,country,academic_year) VALUES($1,$2,$3,$4,$5,$6,$7)', [req.user.id, b.subject, score, total, b.mode || 'practice', req.user.country || 'Global', req.user.academic_year || CURRENT_YEAR]);
    await pgQuery('UPDATE users SET xp=xp+$1,quiz_points=quiz_points+$2,updated_at=NOW() WHERE id=$3', [xp, score, req.user.id]);
  } else {
    db.scores.push({ id: Date.now() + Math.random(), user_id: req.user.id, subject: b.subject, score, total, mode: b.mode || 'practice', country: req.user.country || 'Global', academic_year: req.user.academic_year || CURRENT_YEAR, created_at: new Date().toISOString() });
    req.user.xp = Number(req.user.xp || 0) + xp; req.user.quiz_points = Number(req.user.quiz_points || 0) + score; saveDb();
  }
  res.status(201).json({ ok: true, earnedXp: xp });
});

app.get('/api/leaderboard', async (req, res) => {
  const country = String(req.query.country || '').trim();
  const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 100);
  if (pool) {
    const params = [];
    let where = '';
    if (country) { params.push(country); where = `WHERE country=$${params.length}`; }
    params.push(limit);
    const rows = await pgQuery(`SELECT id,name,university,country,level,academic_year,xp,quiz_points FROM users ${where} ORDER BY xp DESC,quiz_points DESC LIMIT $${params.length}`, params);
    return res.json({ leaderboard: rows });
  }
  let rows = db.users.map(safeUser); if (country) rows = rows.filter(x => x.country === country);
  res.json({ leaderboard: rows.sort((a,b) => b.xp - a.xp || b.quiz_points - a.quiz_points).slice(0, limit) });
});

// Premium / Paystack
app.post('/api/payments/paystack/initialize', requireAuth, async (req, res) => {
  if (!PAYSTACK_SECRET_KEY) return res.status(503).json({ error: 'Paystack is not configured yet. Add PAYSTACK_SECRET_KEY on the server.' });
  if (req.user.premium) return res.json({ ok: true, alreadyPremium: true, user: safeUser(req.user) });
  const reference = randomReference();
  const metadata = { user_id: String(req.user.id), product: 'premium', product_name: PREMIUM_NAME, app_version: APP_VERSION };
  const callback = PAYSTACK_CALLBACK_URL || `${req.protocol}://${req.get('host')}/api/payments/paystack/callback`;
  try {
    const data = await paystackRequest('/transaction/initialize', {
      method: 'POST', body: JSON.stringify({ email: req.user.email, amount: String(PREMIUM_AMOUNT_SUBUNIT), currency: PAYSTACK_CURRENCY, reference, callback_url: callback, metadata })
    });
    await recordPaymentPending({ userId: req.user.id, reference, amount: PREMIUM_AMOUNT_SUBUNIT, currency: PAYSTACK_CURRENCY, metadata });
    await audit(req.user.id, 'premium_payment_initialized', { reference });
    res.json({ ok: true, authorization_url: data.data.authorization_url, access_code: data.data.access_code, reference });
  } catch (e) { res.status(e.status === 400 ? 400 : 502).json({ error: e.message }); }
});

app.get('/api/payments/paystack/verify/:reference', requireAuth, async (req, res) => {
  const reference = String(req.params.reference || '');
  const payment = await getPayment(reference);
  if (!payment || String(payment.user_id) !== String(req.user.id)) return res.status(404).json({ error: 'Payment not found.' });
  try {
    const data = await paystackRequest(`/transaction/verify/${encodeURIComponent(reference)}`, { method: 'GET' });
    const result = await fulfillPremium(reference, data);
    const user = await getUserById(req.user.id);
    res.json({ ok: result.ok, result, user: safeUser(user), verification: { status: data.data?.status, amount: data.data?.amount, currency: data.data?.currency, reference: data.data?.reference } });
  } catch (e) { res.status(502).json({ error: e.message }); }
});

app.get('/api/payments/paystack/callback', async (req, res) => {
  const reference = String(req.query.reference || '');
  if (!reference) return res.redirect('/?payment=missing');
  try {
    const data = await paystackRequest(`/transaction/verify/${encodeURIComponent(reference)}`, { method: 'GET' });
    await fulfillPremium(reference, data);
    res.redirect(`/?payment=${data.data?.status === 'success' ? 'success' : 'failed'}`);
  } catch { res.redirect('/?payment=error'); }
});

app.post('/api/payments/paystack/webhook', async (req, res) => {
  if (!PAYSTACK_SECRET_KEY) return res.sendStatus(503);
  const signature = req.get('x-paystack-signature') || '';
  const raw = req.rawBody || Buffer.from(JSON.stringify(req.body || {}));
  const expected = crypto.createHmac('sha512', PAYSTACK_SECRET_KEY).update(raw).digest('hex');
  if (!signature || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.sendStatus(401);
  // Acknowledge quickly; processing here is intentionally small and idempotent.
  const event = req.body || {};
  res.sendStatus(200);
  if (event.event === 'charge.success' && event.data?.reference) {
    try { await fulfillPremium(event.data.reference, event); } catch (e) { console.error('Paystack webhook fulfillment error:', e.message); }
  }
});

// Admin question management
app.get('/api/admin/questions', requireAdmin, async (_req, res) => {
  if (pool) return res.json({ questions: await pgQuery('SELECT * FROM questions ORDER BY id DESC LIMIT 500') });
  res.json({ questions: db.questions.slice().sort((a,b) => Number(b.id) - Number(a.id)).slice(0, 500) });
});

app.post('/api/admin/questions', requireAdmin, async (req, res) => {
  const b = req.body || {};
  if (!b.subject || !b.question || !Array.isArray(b.options) || b.options.length !== 4 || !Number.isInteger(Number(b.answer_index))) return res.status(400).json({ error: 'subject, question, four options and answer_index are required.' });
  const q = {
    subject: String(b.subject), course_code: String(b.course_code || ''), country: String(b.country || 'Global'), academic_year: String(b.academic_year || CURRENT_YEAR), level: String(b.level || 'All'), difficulty: String(b.difficulty || 'medium'), mode: String(b.mode || 'practice'), question: String(b.question), options: b.options.map(String), answer_index: Number(b.answer_index), explanation: String(b.explanation || ''), source_note: String(b.source_note || '')
  };
  if (q.answer_index < 0 || q.answer_index > 3) return res.status(400).json({ error: 'answer_index must be 0, 1, 2 or 3.' });
  if (pool) {
    const row = (await pgQuery(`INSERT INTO questions(subject,course_code,country,academic_year,level,difficulty,mode,question,options,answer_index,explanation,source_note)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`, [q.subject,q.course_code,q.country,q.academic_year,q.level,q.difficulty,q.mode,q.question,JSON.stringify(q.options),q.answer_index,q.explanation,q.source_note]))[0];
    await audit(req.user.id, 'question_created', { id: row.id }); return res.status(201).json({ question: row });
  }
  const row = { id: Date.now(), ...q, active: true, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }; db.questions.push(row); saveDb(); await audit(req.user.id, 'question_created', { id: row.id }); res.status(201).json({ question: row });
});

app.patch('/api/admin/questions/:id', requireAdmin, async (req, res) => {
  const id = String(req.params.id); const b = req.body || {};
  if (pool) {
    const row = (await pgQuery(`UPDATE questions SET subject=COALESCE($1,subject),course_code=COALESCE($2,course_code),country=COALESCE($3,country),academic_year=COALESCE($4,academic_year),level=COALESCE($5,level),difficulty=COALESCE($6,difficulty),mode=COALESCE($7,mode),question=COALESCE($8,question),options=COALESCE($9,options),answer_index=COALESCE($10,answer_index),explanation=COALESCE($11,explanation),source_note=COALESCE($12,source_note),active=COALESCE($13,active),updated_at=NOW() WHERE id=$14 RETURNING *`, [b.subject,b.course_code,b.country,b.academic_year,b.level,b.difficulty,b.mode,b.question,b.options ? JSON.stringify(b.options) : null,b.answer_index,b.explanation,b.source_note,b.active,id]))[0];
    if (!row) return res.status(404).json({ error: 'Question not found.' }); return res.json({ question: row });
  }
  const row = db.questions.find(q => String(q.id) === id); if (!row) return res.status(404).json({ error: 'Question not found.' }); Object.assign(row, b, { updated_at: new Date().toISOString() }); saveDb(); res.json({ question: row });
});

app.delete('/api/admin/questions/:id', requireAdmin, async (req, res) => {
  const id = String(req.params.id);
  if (pool) { const r = await pgQuery('UPDATE questions SET active=FALSE,updated_at=NOW() WHERE id=$1 RETURNING id', [id]); if (!r.length) return res.status(404).json({ error: 'Question not found.' }); }
  else { const q = db.questions.find(x => String(x.id) === id); if (!q) return res.status(404).json({ error: 'Question not found.' }); q.active = false; q.updated_at = new Date().toISOString(); saveDb(); }
  res.json({ ok: true });
});

// Static SPA. Express 5-safe fallback: no wildcard string route is used.
app.use(express.static(PUBLIC_DIR, { index: 'index.html', maxAge: NODE_ENV === 'production' ? '1h' : 0 }));
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api/')) return res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
  next();
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: NODE_ENV === 'production' ? 'Internal server error.' : err.message });
});

async function start() {
  try {
    if (pool) await initPostgres();
    else console.warn('DATABASE_URL is not set: using local JSON database. Use PostgreSQL for persistent production storage.');
    app.listen(PORT, () => console.log(`DENexpharm v${APP_VERSION} listening on port ${PORT}`));
  } catch (e) { console.error('Startup failed:', e); process.exit(1); }
}
start();
